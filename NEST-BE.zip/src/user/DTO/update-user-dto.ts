export interface UpdateUserDto {
  email: string;
  name: string;
  role: string;
}

export interface DeleteUserDto {
  email: string;
}
